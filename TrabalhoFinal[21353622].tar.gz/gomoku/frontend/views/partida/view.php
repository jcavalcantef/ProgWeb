<?php

use yii\helpers\Html;
use yii\widgets\DetailView;
use frontend\models\User;
use yii\helpers\Url;
use yii\widgets\Pjax;


/* @var $this yii\web\View */
/* @var $model frontend\models\Partida */


$this->params['breadcrumbs'][] = ['label' => 'Partidas', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;

//Inserir o css
$this->registerCssFile('css/estilo.css');
// Inserir JS
$this->registerJsFile('js/gmk.js');

if (!$vencedor) {
$this->registerJs('
    setInterval(function() {
        recarregar = document.getElementById("recarregar");
        recarregar.click();
    }, 1000);
');
}

?>
<?php Pjax::begin(); ?>
<div class="partida-view">

    <h1><?= Html::encode($this->title) ?></h1>


    <!-- ADICIONAR: DetailView contendo os participantes do jogo -->
    <table id="w1" class="table table-striped table-bordered detail-view">
        <tr>
            <th><img id="jogador_1" src="img/1.gif" width=20 /> Jogador 1 </th>
            <td> <?php if($model->id_user_1 != NULL) {  $modelUser = User::findOne($id = $model->id_user_1 ); echo $modelUser->username; }  ?> </td>
        </tr>
        <tr>
            <th><img id="jogador_2" src="img/2.gif" width=20 /> Jogador 2 </th>
            <td><?php if($model->id_user_2 != NULL){ $modelUser = User::findOne($id = $model->id_user_2 ); echo $modelUser->username; } ?></td>
        </tr>
        <tr>
            <th>Vencedor</th>
            <td>Vencedor não definido</td>
        </tr>
    </table>

    <!-- Link usado pelo Pjax, para carregar o tabuleiro a cada segundo -->
    <?= Html::a('Recarregar',['partida/view','id'=>$model->id],['id'=>'recarregar','style'=>'display:none']) ?> 

    <div class="container">
        <table class="tabuleiro">
        <?php
            for($linha=0; $linha<15; $linha++){
                echo "<tr>";
                for($coluna = 0; $coluna<15; $coluna++){

                    $url = Url::to(['partida/view','id' => $model->id, 'linha' => $linha, 'coluna' => $coluna]);

                    if($vencedor != 0){
                        if($jogadas[$linha][$coluna] == $model->id_user_1){
                            echo "<td> <img src='img/1.gif' width = 32 /> </td>";
                        }else if($jogadas[$linha][$coluna] == $model->id_user_2){
                            echo "<td> <img src='img/2.gif' width = 32 /> </td>";
                        }else{
                            echo "<td> <img src='img/0.gif' width = 32 /> </td>";
                        }
                    }else if($jogador_da_vez == Yii::$app->user->id){
                        echo "<td id='c_".$linha."_".$coluna."'><a href='".$url."' onclick='Clicked(".$linha .",".$coluna.",".Yii::$app->user->id.")'> <img src = 'img/0.gif' width = 32 /> </a> </td>";
                    }else {
                        echo "<td id='c_" . $linha . "_" . $coluna . "'> <img src = 'img/0.gif' width = 32 /> </td>";
                    }

                    if($jogadas[$linha][$coluna] != 0){
                        $this->registerJs("Clicked(" . $linha . "," . $coluna . "," . $jogadas[$linha][$coluna] . ");");
                    }
                }
                echo "</tr>";
            }
         ?>
        </table>
        
       <!-- <span id="jog_1" data-user=<?php $model->id_user_1; ?> style="display:none" /> 
        <span id="jog_2" data-user=<?php $model->id_user_2; ?> style="display:none" /> -->

        <div id="id01" class="w3-modal">
            <div class="w3-modal-content">
                <div class="w3-container">
                  <span onclick="document.getElementById('id01').style.display='none'" class="w3-closebtn">&times;</span>
                  <p id="win"></p>
                </div>
            </div>
        </div>      
        
        <span id="vencedor" data-value=<?php echo $vencedor; ?> style="display:none" />
    </div> 


</div>
<?php Pjax::end(); ?>