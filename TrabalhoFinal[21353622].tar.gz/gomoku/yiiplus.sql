-- phpMyAdmin SQL Dump
-- version 4.5.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Tempo de geração: 22/09/2016 às 04:27
-- Versão do servidor: 10.1.10-MariaDB
-- Versão do PHP: 5.6.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `yiiplus`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `comentario`
--

CREATE TABLE `comentario` (
  `id` int(11) NOT NULL,
  `nome` varchar(45) NOT NULL,
  `sexo` char(1) NOT NULL,
  `comentarios` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura para tabela `curso`
--

CREATE TABLE `curso` (
  `id` int(11) NOT NULL,
  `nome` varchar(45) NOT NULL,
  `sigla` char(4) NOT NULL,
  `descricao` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Fazendo dump de dados para tabela `curso`
--

INSERT INTO `curso` (`id`, `nome`, `sigla`, `descricao`) VALUES
(1, 'Ciencia da Computacao', 'CC', 'Melhor curso da UFAM =)'),
(2, 'Sistema da Informacao', 'SI', 'Lorem Ipsum é simplesmente uma simulação de texto da indústria tipográfica e de impressos, e vem sendo utilizado desde o século XVI, quando um impressor desconhecido pegou uma bandeja de tipos e os embaralhou para fazer um livro de modelos de tipos. Lorem Ipsum sobreviveu não só a cinco séculos, como também ao salto para a editoração eletrônica, permanecendo essencialmente inalterado.');

-- --------------------------------------------------------

--
-- Estrutura para tabela `jogada`
--

CREATE TABLE `jogada` (
  `id` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `id_partida` int(11) NOT NULL,
  `linha` int(11) NOT NULL,
  `coluna` int(11) NOT NULL,
  `data_hora` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Fazendo dump de dados para tabela `jogada`
--

INSERT INTO `jogada` (`id`, `id_user`, `id_partida`, `linha`, `coluna`, `data_hora`) VALUES
(99, 1, 41, 0, 0, '2016-09-21 13:37:23'),
(100, 1, 41, 0, 0, '2016-09-21 13:37:31'),
(101, 1, 41, 0, 0, '2016-09-21 13:37:35'),
(102, 2, 41, 0, 1, '2016-09-21 13:38:48'),
(103, 2, 41, 0, 1, '2016-09-21 13:38:52'),
(104, 1, 41, 0, 0, '2016-09-21 13:38:56'),
(105, 1, 41, 0, 0, '2016-09-21 13:39:38'),
(106, 2, 41, 0, 1, '2016-09-21 13:39:44'),
(107, 1, 41, 0, 0, '2016-09-21 13:39:48'),
(108, 1, 41, 0, 0, '2016-09-21 13:39:49'),
(109, 1, 41, 0, 0, '2016-09-21 13:39:51'),
(110, 1, 41, 0, 0, '2016-09-21 13:39:51'),
(111, 1, 41, 0, 0, '2016-09-21 13:39:51'),
(112, 1, 41, 0, 0, '2016-09-21 13:39:51'),
(113, 1, 41, 0, 0, '2016-09-21 13:39:51'),
(114, 1, 41, 0, 0, '2016-09-21 13:39:52'),
(115, 1, 41, 0, 0, '2016-09-21 13:39:56'),
(116, 1, 41, 0, 0, '2016-09-21 13:39:58'),
(117, 1, 41, 0, 0, '2016-09-21 13:40:00'),
(118, 1, 41, 0, 0, '2016-09-21 13:40:01'),
(119, 1, 41, 0, 0, '2016-09-21 13:40:01'),
(120, 1, 41, 0, 0, '2016-09-21 13:40:01'),
(121, 1, 41, 0, 0, '2016-09-21 13:40:01'),
(122, 1, 41, 0, 0, '2016-09-21 13:40:01'),
(123, 1, 41, 0, 0, '2016-09-21 13:40:02'),
(124, 1, 41, 0, 0, '2016-09-21 13:40:05'),
(125, 1, 41, 0, 0, '2016-09-21 13:40:05'),
(126, 1, 41, 0, 0, '2016-09-21 13:40:05'),
(127, 1, 41, 0, 0, '2016-09-21 13:40:05'),
(128, 1, 41, 0, 0, '2016-09-21 13:40:05'),
(129, 1, 41, 0, 0, '2016-09-21 13:40:05'),
(130, 1, 41, 0, 0, '2016-09-21 13:40:24'),
(131, 1, 41, 0, 0, '2016-09-21 13:40:27'),
(132, 1, 41, 0, 0, '2016-09-21 13:40:29'),
(133, 1, 41, 0, 0, '2016-09-21 13:40:31'),
(134, 1, 41, 0, 0, '2016-09-21 13:40:32'),
(135, 1, 41, 0, 0, '2016-09-21 13:40:46'),
(136, 2, 41, 0, 1, '2016-09-21 13:41:03'),
(137, 1, 41, 0, 2, '2016-09-21 13:41:14'),
(138, 2, 41, 0, 3, '2016-09-21 13:41:42'),
(139, 1, 41, 0, 4, '2016-09-21 13:41:51'),
(140, 1, 41, 0, 4, '2016-09-21 13:41:59'),
(141, 1, 41, 0, 4, '2016-09-21 13:42:02'),
(142, 2, 41, 0, 3, '2016-09-21 13:42:08'),
(143, 2, 41, 0, 3, '2016-09-21 13:42:33'),
(144, 2, 41, 0, 3, '2016-09-21 13:42:49'),
(145, 1, 41, 0, 4, '2016-09-21 13:42:51'),
(146, 2, 41, 0, 5, '2016-09-21 13:42:59'),
(147, 1, 41, 0, 6, '2016-09-21 13:43:06'),
(148, 2, 41, 0, 7, '2016-09-21 13:43:16'),
(149, 1, 41, 0, 8, '2016-09-21 13:43:25'),
(150, 2, 41, 0, 9, '2016-09-21 13:44:05'),
(151, 1, 41, 0, 10, '2016-09-21 16:21:04'),
(152, 1, 41, 0, 10, '2016-09-21 16:21:06'),
(153, 2, 41, 0, 11, '2016-09-21 16:21:17');

-- --------------------------------------------------------

--
-- Estrutura para tabela `migration`
--

CREATE TABLE `migration` (
  `version` varchar(180) NOT NULL,
  `apply_time` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Fazendo dump de dados para tabela `migration`
--

INSERT INTO `migration` (`version`, `apply_time`) VALUES
('m000000_000000_base', 1464288272),
('m130524_201442_init', 1464288300);

-- --------------------------------------------------------

--
-- Estrutura para tabela `partida`
--

CREATE TABLE `partida` (
  `id` int(11) NOT NULL,
  `id_user_1` int(11) DEFAULT NULL,
  `id_user_2` int(11) DEFAULT NULL,
  `vencedor` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Fazendo dump de dados para tabela `partida`
--

INSERT INTO `partida` (`id`, `id_user_1`, `id_user_2`, `vencedor`) VALUES
(41, 1, 2, NULL),
(42, 2, 1, NULL);

-- --------------------------------------------------------

--
-- Estrutura para tabela `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `username` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `auth_key` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `curso_id` int(11) DEFAULT NULL,
  `password_hash` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password_reset_token` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` smallint(6) NOT NULL DEFAULT '10',
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Fazendo dump de dados para tabela `user`
--

INSERT INTO `user` (`id`, `username`, `auth_key`, `curso_id`, `password_hash`, `password_reset_token`, `email`, `status`, `created_at`, `updated_at`) VALUES
(1, 'jonathas', 'FSJitO13H8W9vh8vAou67FX2U1HuVuZK', 1, '$2y$13$Ry6lWMWV5Err3XcqOr4ZR.ULtcTVzrEy9eLFoNxjKOcJYZpI8dwla', '', 'jonathasborges0@gmail.com', 10, 1473293253, 1473293253),
(2, 'cavalcante', 'ZT0vTusOW4FoA2tYk-99ex44IdSuxrIj', 2, '$2y$13$cNzcgpIBBIMWbjXXD6IvZuiEbxrcNTgjcLtnHZIq5Or4luOH10nf6', NULL, 'cavalcante@gmail.com', 10, 1474319164, 1474319164),
(6, 'teste', 'F91mGpid7K_bpCr8xcEUH7TheynHL0xO', 2, '$2y$13$q1lf34CC3191Wt5vyuhdLuBwSifIhgpn4D28Yx11L1afbw5SiTZ/y', NULL, 'teste@gmail.com', 10, 1474413351, 1474413351);

--
-- Índices de tabelas apagadas
--

--
-- Índices de tabela `comentario`
--
ALTER TABLE `comentario`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `curso`
--
ALTER TABLE `curso`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `jogada`
--
ALTER TABLE `jogada`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id_fk` (`id_user`),
  ADD KEY `partida_id_fk` (`id_partida`);

--
-- Índices de tabela `migration`
--
ALTER TABLE `migration`
  ADD PRIMARY KEY (`version`);

--
-- Índices de tabela `partida`
--
ALTER TABLE `partida`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id_fk` (`id_user_1`) USING BTREE,
  ADD KEY `user_id_2_fk` (`id_user_2`),
  ADD KEY `vencedor_fk` (`vencedor`);

--
-- Índices de tabela `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `password_reset_token` (`password_reset_token`),
  ADD KEY `curso_fk` (`curso_id`);

--
-- AUTO_INCREMENT de tabelas apagadas
--

--
-- AUTO_INCREMENT de tabela `comentario`
--
ALTER TABLE `comentario`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de tabela `curso`
--
ALTER TABLE `curso`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT de tabela `jogada`
--
ALTER TABLE `jogada`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=154;
--
-- AUTO_INCREMENT de tabela `partida`
--
ALTER TABLE `partida`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;
--
-- AUTO_INCREMENT de tabela `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- Restrições para dumps de tabelas
--

--
-- Restrições para tabelas `jogada`
--
ALTER TABLE `jogada`
  ADD CONSTRAINT `jogada_partida_fk` FOREIGN KEY (`id_partida`) REFERENCES `partida` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `jogada_user_fk` FOREIGN KEY (`id_user`) REFERENCES `user` (`id`);

--
-- Restrições para tabelas `partida`
--
ALTER TABLE `partida`
  ADD CONSTRAINT `partida_usuario_1_fk` FOREIGN KEY (`id_user_1`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `partida_usuario_2_fk` FOREIGN KEY (`id_user_2`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `partida_vencedor_fk` FOREIGN KEY (`vencedor`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Restrições para tabelas `user`
--
ALTER TABLE `user`
  ADD CONSTRAINT `curso_user_fk` FOREIGN KEY (`curso_id`) REFERENCES `curso` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
