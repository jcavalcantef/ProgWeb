Professor eu não consegui terminar a função do vencedor na aplicação do yii em virtude da minha solução em javascript ter ficado muito extensa, acho que nem se tivesse tempo eu conseguiria fazer.

Abaixo vai minha solução para encontrar o vencedor, deu muito trabalho fazer espero que considere o esforço

(OBS: Essa foi a solução para o trabalho passado em javascript) esse arquivo na íntegra se encontra em gomoku/frontend/web/js

fora isso todas as funcionalidades estão de acordo com o pedido, caso tenha algum problema por favor me avise.

//Verifica Vencedor
function verificaVencedor(i,j,jogador) {

	if(verificaNorte(i,j,jogador))    return true; // verifica sul tambem 
	if(verificaLeste(i,j,jogador))    return true; // verifica oeste tambem
	if(verificaNordeste(i,j,jogador)) return true; // verifica sudoeste tambem
	if(verificaNoroeste(i,j,jogador)) return true; // verifica sudoeste tambem

	return false;
}

function verificaNorte(i,j,jogador){
	if(jogador == 'X') ganhadorX++;
	if(jogador == 'O') ganhadorO++;
	var conta = 1;
	var flag = 0;
	if(i > 3){
		for(conta = 1; conta < 5; conta++){ // verifica 4 blocos acima
			flag = auxNorte(i,j,flag,conta,jogador); if( flag == 1) break;
			if(document.getElementById((i-conta) + ","+j).src.endsWith("1.gif") && (jogador == 'X' ) ) ganhadorX++;
			if(document.getElementById((i-conta) + ","+j).src.endsWith("2.gif") && (jogador == 'O' ) ) ganhadorO++;
		}
	}else{
		if( i == 0); // não verifica
		if( i == 1) { // verifica 1 bloco acima
			flag = auxNorte(i,j,flag,conta,jogador);
			if(document.getElementById((i-conta) + ","+j).src.endsWith("1.gif") && (jogador == 'X' ) ) ganhadorX++;
			if(document.getElementById((i-conta) + ","+j).src.endsWith("2.gif") && (jogador == 'O' ) ) ganhadorO++;
		} 
		if( i == 2 ){ // verifica 2 blocos acima
			for(conta = 1; conta < 3; conta++){ 
				flag = auxNorte(i,j,flag,conta,jogador); if( flag == 1) break;
				if(document.getElementById((i-conta) + ","+j).src.endsWith("1.gif") && (jogador == 'X' ) ) ganhadorX++;
				if(document.getElementById((i-conta) + ","+j).src.endsWith("2.gif") && (jogador == 'O' ) ) ganhadorO++;
			}
		}
		if( i == 3){ // verifica 3 blocos acima	
			for(conta = 1; conta < 4; conta++){ 
				flag = auxNorte(i,j,flag,conta,jogador); if( flag == 1) break;
				if(document.getElementById((i-conta) + ","+j).src.endsWith("1.gif") && (jogador == 'X' ) ) ganhadorX++;
				if(document.getElementById((i-conta) + ","+j).src.endsWith("2.gif") && (jogador == 'O' ) ) ganhadorO++;
			}
		}
	}
	if(flag == 0) verificaSul(i,j,jogador);	
	console.log("ganhadorX "+ ganhadorX);
	console.log("ganhadorO "+ ganhadorO);
	if(ganhadorX > 4)  return true;
	if(ganhadorO > 4)  return true;
	setaGanhador();
	return false;
}	
function verificaNordeste(i,j,jogador) {
	if(jogador == 'X') ganhadorX++;
	if(jogador == 'O') ganhadorO++;
	var conta = 1;
	var flag = 0;
	if( (i > 3 ) && (j < 11) ){ 
		for(conta = 1; conta < 5; conta++){ // verfica 4 blocos acima a direita
			flag = auxNordeste(i,j,flag,conta,jogador); if( flag == 1) break;
			if(document.getElementById((i-conta) + ","+(j+conta)).src.endsWith("1.gif") && (jogador == 'X' ) ) ganhadorX++;
			if(document.getElementById((i-conta) + ","+(j+conta)).src.endsWith("2.gif") && (jogador == 'O' ) ) ganhadorO++;
		}
	}else{
		if( ((i == 0) && (j == 0)) || ((i == 0) && (j == 14)) || ((i == 14) && (j == 14)) ); // não verifica
		if( ((i == 1) && (j == 1)) || ((i == 1) && (j == 13)) || ((i == 13) && (j == 13)) ) { // verifica 1 bloco diagonal acima
			flag = auxNordeste(i,j,flag,conta,jogador);
			if(document.getElementById((i-conta) + ","+(j+conta)).src.endsWith("1.gif") && (jogador == 'X' ) ) ganhadorX++;
			if(document.getElementById((i-conta) + ","+(j+conta)).src.endsWith("2.gif") && (jogador == 'O' ) ) ganhadorO++;
		} 
		if( ((i == 2) && (j == 2)) || ((i == 2) && (j == 12)) || ((i == 12) && (j == 12)) ){ // verifica 2 blocos a noroeste
			for(conta = 1; conta < 3; conta++){ 
				flag = auxNordeste(i,j,flag,conta,jogador); if( flag == 1) break;
				if(document.getElementById((i-conta) + ","+(j+conta)).src.endsWith("1.gif") && (jogador == 'X' ) ) ganhadorX++;
				if(document.getElementById((i-conta) + ","+(j+conta)).src.endsWith("2.gif") && (jogador == 'O' ) ) ganhadorO++;
			}
		}
		if( ((i == 3) && (j == 3)) || ((i == 3) && (j == 11)) || ((i == 11) && (j == 11)) ){ // verifica 3 blocos acima	
			for(conta = 1; conta < 4; conta++){ 
				flag = auxNordeste(i,j,flag,conta,jogador); if( flag == 1) break;
				if(document.getElementById((i-conta) + ","+(j+conta)).src.endsWith("1.gif") && (jogador == 'X' ) ) ganhadorX++;
				if(document.getElementById((i-conta) + ","+(j+conta)).src.endsWith("2.gif") && (jogador == 'O' ) ) ganhadorO++;
			}
		}
	}
	if(flag == 0) verificaSudoeste(i,j,jogador);	
	if(ganhadorX > 4) alert("ganhou o X");
	if(ganhadorO > 4) alert("ganhou o O");
	setaGanhador();
}
function verificaLeste(i,j,jogador) {
	if(jogador == 'X') ganhadorX++;
	if(jogador == 'O') ganhadorO++;
	var conta = 1;
	var flag = 0;
	if(j < 11){
		for(conta = 1; conta < 5; conta++){ // verifica 4 bloco a direita 
			flag = auxLeste(i,j,flag,conta,jogador); if( flag == 1) break;
			if(document.getElementById(i + ","+ (j+conta)).src.endsWith("1.gif") && (jogador == 'X' ) ) ganhadorX++;
			if(document.getElementById(i + ","+ (j+conta)).src.endsWith("2.gif") && (jogador == 'O' ) ) ganhadorO++;
		}
	}else{
		if( j == 14 ); // não verifica
		if( j == 13 ) { // verifica 1 bloco a direita 
			if(document.getElementById(i + ","+(j+conta)).src.endsWith("1.gif") && (jogador == 'X' ) ) ganhadorX++;
			if(document.getElementById(i + ","+(j+conta)).src.endsWith("2.gif") && (jogador == 'O' ) ) ganhadorO++;
		} 
		if( j == 12 ){ // verifica 2 blocos a direita
			for(conta = 1; conta < 3; conta++){
				flag = auxLeste(i,j,flag,conta,jogador); if( flag == 1) break; 
				if(document.getElementById(i + ","+(j+conta)).src.endsWith("1.gif") && (jogador == 'X' ) ) ganhadorX++;
				if(document.getElementById(i + ","+(j+conta)).src.endsWith("2.gif") && (jogador == 'O' ) ) ganhadorO++;
			}
		}
		if( j == 11 ){ // verifica 3 blocos direita	
			for(conta = 1; conta < 4; conta++){
				flag = auxLeste(i,j,flag,conta,jogador); if( flag == 1) break; 
				if(document.getElementById(i + ","+(j+conta)).src.endsWith("1.gif") && (jogador == 'X' ) ) ganhadorX++;
				if(document.getElementById(i + ","+(j+conta)).src.endsWith("2.gif") && (jogador == 'O' ) ) ganhadorO++;
			}
		}
	}
	if(flag == 0) verificaOeste(i,j,jogador);
	if(ganhadorX > 4) alert("ganhou o X");
	if(ganhadorO > 4) alert("ganhou o O");
	setaGanhador();
}

function verificaSudeste(i,j,jogador) {
	var conta = 1;
	if( (i < 11 ) && (j < 11) ){ // verifica 4 blocos a direita abaixo
		for(conta = 1; conta < 5; conta++){
			if(document.getElementById((i+conta) + ","+(j+conta)).src.endsWith("0.gif")){ break;} 
			if(document.getElementById((i+conta) + ","+(j+conta)).src.endsWith("1.gif") && (jogador == 'X' ) ) ganhadorX++;
			if(document.getElementById((i+conta) + ","+(j+conta)).src.endsWith("2.gif") && (jogador == 'O' ) ) ganhadorO++;
		}
	}else{
		if( ((i == 0) && (j == 14)) || ((i == 14) && (j == 0)) || ((i == 14) && (j == 14)) ); // não verifica
		if( ((i == 1) && (j == 13)) || ((i == 13) && (j == 1)) || ((i == 13) && (j == 13))  ) { // verifica 1 bloco  a direita abaixo		
			if(document.getElementById((i+conta) + ","+(j+conta)).src.endsWith("1.gif") && (jogador == 'X' ) ) ganhadorX++;
			if(document.getElementById((i+conta) + ","+(j+conta)).src.endsWith("2.gif") && (jogador == 'O' ) ) ganhadorO++;
		} 
		if( ((i == 2) && (j == 12)) || ((i == 12) && (j == 2)) || ((i == 12) && (j == 12)) ){ // verifica 2 blocos a direita abaixo
			for(conta = 1; conta < 3; conta++){ 
				if(document.getElementById((i+conta) + ","+(j+conta)).src.endsWith("0.gif")){ break;} 
				if(document.getElementById((i+conta) + ","+(j+conta)).src.endsWith("1.gif") && (jogador == 'X' ) ) ganhadorX++;
				if(document.getElementById((i+conta) + ","+(j+conta)).src.endsWith("2.gif") && (jogador == 'O' ) ) ganhadorO++;
			}
		}
		if( ((i == 3) && (j == 11)) || ((i == 11) && (j == 3)) || ((i == 11) && (j == 11))  ){ // verifica 3 blocos a direita abaixo
			for(conta = 1; conta < 4; conta++){ 
				if(document.getElementById((i+conta) + ","+(j+conta)).src.endsWith("0.gif")){ break;}  
				if(document.getElementById((i+conta) + ","+(j+conta)).src.endsWith("1.gif") && (jogador == 'X' ) ) ganhadorX++;
				if(document.getElementById((i+conta) + ","+(j+conta)).src.endsWith("2.gif") && (jogador == 'O' ) ) ganhadorO++;
			}
		}
	}
}
function verificaSul(i,j,jogador) {
	var conta = 1;
	if((i < 11) ){ // verifica 4 blocos abaixo
		for(conta = 1; conta < 5; conta++){
			if(document.getElementById((i+conta) + ","+j).src.endsWith("0.gif")){ break;} 
			if(document.getElementById((i+conta) + ","+j).src.endsWith("1.gif") && (jogador == 'X' ) ) ganhadorX++;
			if(document.getElementById((i+conta) + ","+j).src.endsWith("2.gif") && (jogador == 'O' ) ) ganhadorO++;
		}
	}else{
		if( i == 14);  // não verifica
		if( i == 13) { // verifica 1 bloco abaixo
			if(document.getElementById((i+conta) + ","+j).src.endsWith("1.gif") && (jogador == 'X' ) ) ganhadorX++;
			if(document.getElementById((i+conta) + ","+j).src.endsWith("2.gif") && (jogador == 'O' ) ) ganhadorO++;
		} 
		if( i == 12 ){ // verifica 2 blocos acima 
			for(conta = 1; conta < 3; conta++){
				if(document.getElementById((i+conta) + ","+j).src.endsWith("0.gif")){ break;} 
				if(document.getElementById((i+conta) + ","+j).src.endsWith("1.gif") && (jogador == 'X' ) ) ganhadorX++;
				if(document.getElementById((i+conta) + ","+j).src.endsWith("2.gif") && (jogador == 'O' ) ) ganhadorO++;
			}
		}
		if( i == 11){ // verifica 3 blocos acima
			for(conta = 1; conta < 4; conta++){
				if(document.getElementById((i+conta) + ","+j).src.endsWith("0.gif")){ break;} 
				if(document.getElementById((i+conta) + ","+j).src.endsWith("1.gif") && (jogador == 'X' ) ) ganhadorX++;
				if(document.getElementById((i+conta) + ","+j).src.endsWith("2.gif") && (jogador == 'O' ) ) ganhadorO++;
			}
		}
	}	
}
function verificaSudoeste(i,j,jogador) {
	
	var conta = 1;
	if( (i < 11 ) && (j > 3) ){ // verifica 4 blocos diagonal abaixo
		for(conta = 1; conta < 5; conta++){
			if(document.getElementById((i+conta) + ","+j).src.endsWith("0.gif")){ break;} 
			if(document.getElementById((i+conta) + ","+(j-conta)).src.endsWith("1.gif") && (jogador == 'X' ) ) ganhadorX++;
			if(document.getElementById((i+conta) + ","+(j-conta)).src.endsWith("2.gif") && (jogador == 'O' ) ) ganhadorO++;
		}
	}else{
		if( ((i == 0) && (j == 0)) || ((i == 14) && (j == 0)) || ((i == 14) && (j == 14)) ); // não verifica
		if( ((i == 1) && (j == 1)) || ((i == 13) && (j == 1)) || ((i == 13) && (j == 13))  ) { // verifica 1 bloco diagonal abaixo		
			if(document.getElementById((i+conta) + ","+(j-conta)).src.endsWith("1.gif") && (jogador == 'X' ) ) ganhadorX++;
			if(document.getElementById((i+conta) + ","+(j-conta)).src.endsWith("2.gif") && (jogador == 'O' ) ) ganhadorO++;
		} 
		if( ((i == 2) && (j == 2)) || ((i == 12) && (j == 2)) || ((i == 12) && (j == 12)) ){ // verifica 2 blocos diagonal abaixo
			for(conta = 1; conta < 3; conta++){ 
				if(document.getElementById((i+conta) + ","+j).src.endsWith("0.gif")){ break;} 
				if(document.getElementById((i+conta) + ","+(j-conta)).src.endsWith("1.gif") && (jogador == 'X' ) ) ganhadorX++;
				if(document.getElementById((i+conta) + ","+(j-conta)).src.endsWith("2.gif") && (jogador == 'O' ) ) ganhadorO++;
			}
		}
		if( ((i == 3) && (j == 3)) || ((i == 11) && (j == 3)) || ((i == 11) && (j == 11))  ){ // verifica 3 blocos diagonal abaixo
			for(conta = 1; conta < 4; conta++){ 
				if(document.getElementById((i+conta) + ","+j).src.endsWith("0.gif")){ break;} 
				if(document.getElementById((i+conta) + ","+(j-conta)).src.endsWith("1.gif") && (jogador == 'X' ) ) ganhadorX++;
				if(document.getElementById((i+conta) + ","+(j-conta)).src.endsWith("2.gif") && (jogador == 'O' ) ) ganhadorO++;
			}
		}
	}
}
function verificaOeste(i,j,jogador) {
	// body...
	var conta = 1;
	if(j > 3){
		for(conta = 1; conta < 5; conta++){ // verifica 4 bloco a esquerda 
			if(document.getElementById(i + ","+ (j-conta)).src.endsWith("0.gif")) { break;} 
			if(document.getElementById(i + ","+ (j-conta)).src.endsWith("1.gif") && (jogador == 'X' ) ) ganhadorX++;
			if(document.getElementById(i + ","+ (j-conta)).src.endsWith("2.gif") && (jogador == 'O' ) ) ganhadorO++;
		}
	}else{
		if( j == 0); // não verifica
		if( j == 1) { // verifica 1 bloco a esquerda 
			if(document.getElementById(i + ","+(j-conta)).src.endsWith("1.gif") && (jogador == 'X' ) ) ganhadorX++;
			if(document.getElementById(i + ","+(j-conta)).src.endsWith("2.gif") && (jogador == 'O' ) ) ganhadorO++;
		} 
		if( j == 2 ){ // verifica 2 blocos a esquerda
			for(conta = 1; conta < 3; conta++){
				if(document.getElementById(i + ","+ (j-conta)).src.endsWith("0.gif")) { break;} 
				if(document.getElementById(i + ","+(j-conta)).src.endsWith("1.gif") && (jogador == 'X' ) ) ganhadorX++;
				if(document.getElementById(i + ","+(j-conta)).src.endsWith("2.gif") && (jogador == 'O' ) ) ganhadorO++;
			}
		}
		if( j == 3){ // verifica 3 blocos esquerda	
			for(conta = 1; conta < 4; conta++){ 
				if(document.getElementById(i + ","+ (j-conta)).src.endsWith("0.gif")) { break;}
				if(document.getElementById(i + ","+(j-conta)).src.endsWith("1.gif") && (jogador == 'X' ) ) ganhadorX++;
				if(document.getElementById(i + ","+(j-conta)).src.endsWith("2.gif") && (jogador == 'O' ) ) ganhadorO++;
			}
		}
	}
}
function verificaNoroeste(i,j,jogador) {
 	if(jogador == 'X') ganhadorX++;
	if(jogador == 'O') ganhadorO++;
	var conta = 1;
	var flag = 0;
	if( (i > 3 ) && (j > 3) ){ 
		for(conta = 1; conta < 5; conta++){ // verifica os 4 blocos acima esquerda
			flag = auxNoroeste(i,j,flag,conta,jogador); if( flag == 1) break;
			if(document.getElementById((i-conta) + ","+(j-conta)).src.endsWith("1.gif") && (jogador == 'X' ) ) ganhadorX++;
			if(document.getElementById((i-conta) + ","+(j-conta)).src.endsWith("2.gif") && (jogador == 'O' ) ) ganhadorO++;
		}
	}else{
		if( ((i == 0) && (j == 0)) || ((i == 0) && (j == 14)) || ((i == 14) && (j == 0)) ); // não verifica
		if( ((i == 1) && (j == 1)) || ((i == 1) && (j == 13)) || ((i == 13) && (j == 1)) ) { // verifica 1 bloco acima esquerda
			flag = auxNoroeste(i,j,flag,conta,jogador);
			if(document.getElementById((i-conta) + ","+(j-conta)).src.endsWith("1.gif") && (jogador == 'X' ) ) ganhadorX++;
			if(document.getElementById((i-conta) + ","+(j-conta)).src.endsWith("2.gif") && (jogador == 'O' ) ) ganhadorO++;
		} 
		if( ((i == 2) && (j == 2)) || ((i == 2) && (j == 12)) || ((i == 12) && (j == 2)) ){ // verifica 2 blocos acima esquerda
			for(conta = 1; conta < 3; conta++){ 
				flag = auxNoroeste(i,j,flag,conta,jogador); if( flag == 1) break;
				if(document.getElementById((i-conta) + ","+(j-conta)).src.endsWith("1.gif") && (jogador == 'X' ) ) ganhadorX++;
				if(document.getElementById((i-conta) + ","+(j-conta)).src.endsWith("2.gif") && (jogador == 'O' ) ) ganhadorO++;
			}
		}
		if( ((i == 3) && (j == 3)) || ((i == 3) && (j == 11)) || ((i == 11) && (j == 3)) ){ // verifica 3 blocos acima esquerda
			for(conta = 1; conta < 4; conta++){ 
				flag = auxNoroeste(i,j,flag,conta,jogador); if( flag == 1) break;
				if(document.getElementById((i-conta) + ","+(j-conta)).src.endsWith("1.gif") && (jogador == 'X' ) ) ganhadorX++;
				if(document.getElementById((i-conta) + ","+(j-conta)).src.endsWith("2.gif") && (jogador == 'O' ) ) ganhadorO++;
			}
		}
	}
	if(flag == 0) verificaSudeste(i,j,jogador);	
	if(ganhadorX > 4) alert("ganhou o X");
	if(ganhadorO > 4) alert("ganhou o O");
	setaGanhador();
}

function auxNorte(i,j,flag,conta,jogador){
	// verifica X até encontrar bloco diferente depois volta a contar do sul
	if((jogador == 'X') && (!(document.getElementById((i-conta) + ","+j).src.endsWith("1.gif"))) ) { 
		flag = 1; verificaSul(i,j,'X'); return flag;
	}
	// verifica O até encontrar bloco diferente depois volta a contar do sul
	if((jogador == 'O') && (!(document.getElementById((i-conta) + ","+j).src.endsWith("2.gif")))  ){
		flag = 1; verificaSul(i,j,'O'); return flag;   
	}
	return 0;	
}
function auxLeste(i,j,flag,conta,jogador){
	//
	if((jogador == 'X') && (!(document.getElementById(i + ","+(j+conta)).src.endsWith("1.gif"))) ) { 
		flag = 1; verificaOeste(i,j,'X'); return flag;
	}
	if((jogador == 'O') && (!(document.getElementById(i + ","+(j+conta)).src.endsWith("2.gif")))  ){
		flag = 1; verificaOeste(i,j,'O'); return flag;   
	}
	return 0;
}
function auxNordeste(i,j,flag,conta,jogador){
	if((jogador == 'X') && (!(document.getElementById((i-conta) + ","+(j+conta)).src.endsWith("1.gif"))) ) { 
		flag = 1; verificaSudoeste(i,j,'X'); return flag;
	}
	if((jogador == 'O') && (!(document.getElementById((i-conta) + ","+(j+conta)).src.endsWith("2.gif")))  ){
		flag = 1; verificaSudoeste(i,j,'O'); return flag;   
	}
	return 0;
}
function auxNoroeste(i,j,flag,jogador){
	if((jogador == 'X') && (!(document.getElementById((i-conta) + ","+(j-conta)).src.endsWith("1.gif"))) ) { 
		flag = 1; verificaSudoeste(i,j,'X'); return flag;
	}
	if((jogador == 'O') && (!(document.getElementById((i-conta) + ","+(j-conta)).src.endsWith("2.gif")))  ){
		flag = 1; verificaSudoeste(i,j,'O'); return flag;   
	}
	return 0;
}